package org.zickit.noGibberish.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class NoGibberishClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

        class_310 client = class_310.method_1551();

        client.execute(() -> {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("Hello from NoGibberish"), false);
            }
        });
    }
}