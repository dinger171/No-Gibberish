package org.zickit.noGibberish.client;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public class NoGibberishClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

        MinecraftClient client = MinecraftClient.getInstance();

        client.execute(() -> {
            if (client.player != null) {
                client.player.sendMessage(Text.literal("Hello from NoGibberish"), false);
            }
        });
    }
}